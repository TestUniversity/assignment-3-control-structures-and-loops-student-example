
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;

import javax.swing.*;

/**
 * DrawingPanel example of a class that extends
 * JPanel so that we can easily Override the paint method.
 * Modified form examples in Programming with Java: A multimedia approach, Chapter 9
 * @author Iain Martin
 *
 */
public class DrawingPanel extends JPanel 
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Image bimage;
	int shapeNumber = 0;  // will use this to change shape to draw
	
	// Define an ArrayList to store our shapes to draw
    ArrayList<Shape> shapes = new ArrayList<Shape>();
  
	// These fields are private but we can set their values
	// using mutator methods that we call from the 
	// GUI_drawing program

	private float image_xpos = 0.0f; // x coordinate of image
	Point startDrag, endDrag;
  
	public DrawingPanel() 
	{
	    // Add a mouse pressed listener, store current mouse coordinates
	    addMouseListener(new MouseAdapter() 
	    {
	    	public void mousePressed(MouseEvent e) 
	    	{
	    		startDrag = new Point(e.getX(), e.getY());
	    		endDrag = startDrag;
	    		repaint();
	    	}

		    // Add a mouse released listener, 
		    // Define the shape from the mouse pressed and mouse release coordinates
		    public void mouseReleased(MouseEvent e) 
		    {
		    	Shape r = makeRectangle(startDrag.x, startDrag.y, e.getX(), e.getY());
		    	shapes.add(r);
		    	startDrag = null;
		    	endDrag = null;
		    	repaint();
		    }
	    });

	    addMouseMotionListener(new MouseMotionAdapter() 
	    {
	    	public void mouseDragged(MouseEvent e) 
	    	{
	    		endDrag = new Point(e.getX(), e.getY());
	    		repaint();
	    	}
	    });
	}
	
  /**
   * Override the paint method. Note that we call
   * the super.paintComponent() method!
   */
  @Override
  public void paintComponent(Graphics g) {
	  Color[] colors = { Color.YELLOW, Color.MAGENTA, Color.CYAN , Color.RED, Color.BLUE, Color.PINK};
	  int colorIndex = 0;
    super.paintComponent(g);
    
    // Gets the Graphics drawing object that we can now draw on.
    Graphics2D 	g2 = (Graphics2D) g;

 // Loop through all the shapes defined in our array list and draw each one
    for (Shape s : shapes) {
      g2.setPaint(Color.BLACK);
      g2.draw(s);
      
      // Change the colour for each rectangle
      g2.setPaint(colors[(colorIndex++) % 6]);
      g2.fill(s);
    }

    // Draw the rectangle we are in the process of defining in a different colour
    if (startDrag != null && endDrag != null) {
      g2.setPaint(Color.LIGHT_GRAY);
      Shape r = makeRectangle(startDrag.x, startDrag.y, endDrag.x, endDrag.y);
      g2.draw(r);
    }
  }

  /**
   * This method should load an image, currently it just sets the field to a new Image.
   * @param i
   */
  public void loadImage(Image i) {
    bimage = i;
    repaint();
  }
  
  /**
   * Draw a rectangle
   * @param x1
   * @param y1
   * @param x2
   * @param y2
   * @return a rectangle defined in Float coordinates
   */
  private Rectangle2D.Float makeRectangle(int x1, int y1, int x2, int y2) {
    return new Rectangle2D.Float(Math.min(x1, x2), Math.min(y1, y2), Math.abs(x1 - x2), Math.abs(y1 - y2));
  }
  
  /**
   * Mutator for number value which is extracted from the textfield
   */
  public void setXPos(float n)
  {
	  image_xpos = n;
	  repaint();
  }
  
  /**
   * Mutator for shape number
   */
  public void setShapeNumber(int n)
  {
	  shapeNumber = n;
  }
  
}
