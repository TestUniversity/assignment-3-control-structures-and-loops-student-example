import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFileChooser;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.border.EtchedBorder;
import javax.swing.filechooser.FileNameExtensionFilter;

/**
 * Example class to provide a 'starter' GUI for  students to work with in the
 * GUI lab.
 * @author Iain Martin, adapted fomr examples from
 * Programming with Java: A multimedia approach: Chapter 9
 */
public class GUI_drawing {

	private JFrame window;
	private JPanel topPanel, sidePanel;
	private DrawingPanel drawingPanel;
//	private JPanel titlePanel;
	private JLabel titleLabel;
	private JFormattedTextField textField;
//	private JCheckBox check1;
	private JFileChooser chooser;
	private JButton button;
	JRadioButton rectangle, ellipse;
	  
	/**
	 * Constructor for our GUI_drawing object
	 */
	public GUI_drawing() {
		// create the window
	    window = new JFrame();

	    // create the panels		
	    createMainPanels();
	    
	    window.setJMenuBar(createMenuBar());  // create menu bar
	    window.setContentPane(topPanel);  // set topPanel as the content pane of this window
	    window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // when window is closed, terminate the program as well	
	    window.setSize(1000, 600);	// set window size
	    window.setTitle("GUI Example for GDUT Students");	// set window title	    
	    window.setVisible(true);	// make window visible
	}
	
	
	/**
	 * This method creates the main panels inside the Window frame
	 */
	public void createMainPanels() 
	{
		BorderLayout layout = new BorderLayout();
		topPanel = new JPanel(layout);
		drawingPanel = new DrawingPanel();
		sidePanel = new JPanel();

		// add drawingPanel to topPanel
		topPanel.add(drawingPanel, BorderLayout.CENTER);
		topPanel.add(sidePanel, BorderLayout.EAST);

		sidePanel.setLayout(new BoxLayout(sidePanel, BoxLayout.Y_AXIS));
		sidePanel.setBorder(BorderFactory.createEtchedBorder(EtchedBorder.RAISED));
		sidePanel.setBackground(Color.lightGray);
		
		// Add the text field panel to the side panel
		sidePanel.add(createTextPanel());
		
		 // Create a JButton
	    button = new JButton("Click Me");
	    sidePanel.add(button);
	    
	    // Add the radio button group to switch between shapes to draw
	    sidePanel.add(createRadioButtons(), BoxLayout.Y_AXIS);
		
		 // action listener for our button
		 button.addActionListener(new ActionListener() {
		     public void actionPerformed(ActionEvent e) {
		        // Add code here to respond to a button click
		    			        
		      }
		    });
		 
		 // Action listener for our radio buttons (rectangle)
		   rectangle.addActionListener(new ActionListener(){
		       public void actionPerformed(ActionEvent e) {
		    	   drawingPanel.setShapeNumber(0);
		       }
		   });
		   
		   // Action listener for our radio buttons (ellipse)
		   ellipse.addActionListener(new ActionListener(){
		       public void actionPerformed(ActionEvent e) {
		    	   drawingPanel.setShapeNumber(1);
		       }
		   });
		
		topPanel.setBackground(Color.lightGray);
	}

	/**
	 * Create a MenuBar with MenuItems and action listeners to respond to events
	 * @return
	 */
	 public JMenuBar createMenuBar() 
	 {
		JMenuBar menuBar = new JMenuBar();   // create a menuBar

		// add a menu called File to menuBar
		JMenu menu = new JMenu("File");
		menuBar.add(menu);
				
		// add a menu item called Open to File
		JMenuItem menuItem = new JMenuItem("Open a file...");
		menu.add(menuItem);

		menuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				selectFile();
		    }
		});

		menuBar.setBackground(Color.lightGray);
		return menuBar;
	}
	 
	 
	 /**
	   * Create a JPanel to store a text field and a label
	   * Includes an event handler and sets a value in the drawing panel
	   * This is to show you how to get a value form a text box and use it!
	   * @return
	   */
	  public JPanel createTextPanel() {
	    JPanel textPanel = new JPanel();
	    JLabel textLabel = new JLabel("TextField:");

	    // create a formatted text field called scaleField
	    textField = new JFormattedTextField(new Float(100));
	    textField.setColumns(3);
	   
	   textPanel.add(textLabel);
	   textPanel.add(textField);

	    textPanel.setMaximumSize(new Dimension(200, 40));
	    textPanel.setBackground(Color.lightGray);
	    return textPanel;
	  }
	  
	  /**
	   * Create a group of radio buttons
	   * @return radio button JPanel
	   */
	  public JPanel createRadioButtons()
	  {
		  JPanel radioButtonPanel = new JPanel();
		    rectangle = new JRadioButton("rectangle");
		    ellipse = new JRadioButton("ellipse");
		    rectangle.setSelected(true); //sets this button as selected on startup
		  
		    // Create the button group to keep only one selected.
		    ButtonGroup btnGroup = new ButtonGroup();
		    btnGroup.add(rectangle);
		    btnGroup.add(ellipse);
		    
		    // Add buttons to the panel
		    radioButtonPanel.add(rectangle);
		    radioButtonPanel.add(ellipse);
		    return radioButtonPanel;
	  }
	 
	 
	 
	/**
	 * This method shows you how to use a FileChooser to enable the user to
	 * select a file. You could then open it and so some stuff with it...
	 */
	public void selectFile() 
	{
		chooser = new JFileChooser();

		// This file filter allows the user to select txt files only
		FileNameExtensionFilter filter = new FileNameExtensionFilter("Text Files", "txt");
		chooser.setFileFilter(filter);
		
		int returnVal = chooser.showOpenDialog(window); // Show file chooser
		
		// Check result ofFileChooser, if user has selected a file then you should call a method
		// to open the file.
		if (returnVal == JFileChooser.APPROVE_OPTION) 
		{
			// open a dialog box to select files 
			File file = chooser.getSelectedFile();	// This is the selected File
		    System.out.println(file.getPath());		// We can then get the file path

		
		 }	
	}
	
	/**
	* Standard main method for Swing GUI
	* @param args String args not used for our GUI
	*/
	public static void main(String [] args)
	{
		// Standard Java Swing method to use Runnable Interface
		// and run the GUI in the dispatch thread using an
		// anonymous class
		javax.swing.SwingUtilities.invokeLater(new Runnable()
		{
			public void run()
			{
				runprogram();
			}
		});
	}
	 
	/*
	 * Static method to create an instance of our
	 * GUI drawing class
	 */
	public static void runprogram()
	{
		// Create an object of our GUI_drawing class
		// The constructor creates the window and panels
		GUI_drawing guiDrawing = new GUI_drawing();	
	}

}
