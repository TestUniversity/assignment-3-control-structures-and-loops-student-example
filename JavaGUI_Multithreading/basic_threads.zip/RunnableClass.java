/**
 * 
 */

/**
 * Example class to show how to create threads through the Runnable interface
 * @author Dr Iain Martin
 * @version 1
 *
 */
public class RunnableClass implements Runnable{
	private String message;
	
	public RunnableClass(String m) {
		message = m;
	}
	
	/**
	 * Runnable classes must implement this method
	 */
	@Override
	public void run()
	{
		for (int i=0; i< 10; i++)
		{
			System.out.println("MyThread: " + message + ": " + i);
		}
	}
}
