/**
 * 
 */

/**
 * @author Dr Iain Martin
 * Example class to show how to create your own thread
 *
 */
public class MyThread extends Thread{

	String message;
	/**
	 * Constructor
	 */
	public MyThread(String m) {
		message = m;
	}

	/**
	 * Method that gets called when the thread is started
	 */
	@Override
	public void run()
	{
		for (int i=0; i< 10; i++)
		{
			System.out.println("MyThread: " + message + ": " + i);
		}
	}
}
