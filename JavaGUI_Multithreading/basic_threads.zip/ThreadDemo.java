/**
 * 
 */

/**
 * @author De Iain Martin
 * @version 1.0
 *
 */
public class ThreadDemo {

	/**
	 * 
	 */
	public ThreadDemo() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ThreadDemo demo = new ThreadDemo();
		
		demo.createThread();
		demo.createRunnableThread();
		demo.printCurrentThread();
		
		for (int i=0; i< 10; i++)
		{
			System.out.println("Main thread: " + i);
		}
	}
	
	/**
	 * prints out the name of the current thread
	 * and the number of active threads
	 */
	private void printCurrentThread()
	{
		Thread t = Thread.currentThread();
		int numThreads = Thread.activeCount();
		
		System.out.println("There are " + numThreads + " active threads estimated.");
		System.out.println("\tCurrent thread = " + t);
		System.out.println("\tCurrent thread name = " + t.getName());
	}
	
	/**
	 * Creates new Threads and starts them
	 */
	private void createThread()
	{
		MyThread myThread1 = new MyThread("First instance");
		MyThread myThread2 = new MyThread("Second instance");
		MyThread myThread3 = new MyThread("Third instance");
		myThread1.start();
		
		myThread2.start();
		myThread3.start();
		
		
	}
	
	/**
	 * Create a runnable class to implement a thread
	 */
	private void createRunnableThread()
	{
		RunnableClass runnable = new RunnableClass("Runnable 1");
		Thread thread = new Thread(runnable);
		thread.start();
	}
}
